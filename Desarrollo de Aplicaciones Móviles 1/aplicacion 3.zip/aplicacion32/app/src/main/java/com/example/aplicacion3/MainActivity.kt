package com.example.aplicacion3

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main)

        // 1. Buscamos el botón con el ID que vimos en el archivo XML ("button")
        val btnIniciarSesion = findViewById<Button>(R.id.button)

// 2. Configuramos el salto
        btnIniciarSesion.setOnClickListener {
            // nombranmos el nombrre de la clase como el nombre de la segunda pantalla a
            // la que queremos cambiar, Pantallainicio2
            val intent = Intent(this, pantallainicio2::class.java)
            startActivity(intent)
        }


        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }
    }
}